Project members: Alex Hoffer, Prathveer Rai, Austin Nguyen
Link to live website to access our visualization interface: http://web.engr.oregonstate.edu/~raip/CS458/Assignment2/php_vis/test.php
Possible players you can enter to visualize: James Harden, Danilo Gallinari, Jordan Clarkson, Jeremy Lin, Jordan Crawford, Nick Young, Tyreke Evans
