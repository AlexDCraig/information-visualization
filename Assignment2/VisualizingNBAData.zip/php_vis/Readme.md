NBA STATS APP USAGE

Instructions-


* The App requires the players_info table to be imported before use or execute the insert_nba.php file. 

* The App works on a filter. And entering a blank name will give it a default players stats.

* The Name filter requires the name to be entered in a specific way, shown in the examples. 

Project members: Alex Hoffer, Prathveer Rai, Austin Nguyen

Link to live website to access our visualization interface: http://web.engr.oregonstate.edu/~raip/CS458/Assignment2/php_vis/test.php

Possible players you can enter to visualize: James Harden, Danilo Gallinari, Jordan Clarkson, Jeremy Lin, Jordan Crawford, Nick Young, Tyreke Evans
